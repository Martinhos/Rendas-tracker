# Gestor Imobiliário — app Android

Projeto Android completo que embrulha o `GestorImobiliario-demo-1.html` numa app nativa.
Funciona **offline**, **sem permissões** e sem qualquer ligação à internet — os dados ficam
no `localStorage` do dispositivo.

Basta compilar para obter o APK. Escolhe um dos três caminhos abaixo.

---

## Caminho A — GitHub Actions (sem instalar nada)

O mais simples se não quiseres instalar o Android Studio. O APK é compilado na nuvem, de graça.

1. Cria um repositório novo no GitHub (pode ser privado).
2. Envia para lá o conteúdo desta pasta (mantendo a estrutura de diretórios).
3. Vai ao separador **Actions** → workflow **Build APK** → **Run workflow**.
   (Também corre sozinho a cada `push` para `main`.)
4. Quando terminar (~3 min), abre a execução e descarrega o artefacto
   **GestorImobiliario-apk**. Lá dentro está o `app-debug.apk`.

Por linha de comandos:

```bash
git init && git add . && git commit -m "Gestor Imobiliario"
git branch -M main
git remote add origin https://github.com/<utilizador>/<repo>.git
git push -u origin main
```

## Caminho B — Android Studio

1. **File → Open** e escolhe esta pasta.
2. Deixa o Gradle sincronizar (o Android Studio trata sozinho do wrapper e do SDK).
3. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
4. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Caminho C — linha de comandos

Precisas do JDK 17 e do Android SDK (com `ANDROID_HOME` definido). O Gradle vem
pelo wrapper, não precisas de o instalar:

```bash
./gradlew assembleDebug
# APK em app/build/outputs/apk/debug/app-debug.apk
```

O wrapper (`gradlew` + `gradle/wrapper/gradle-wrapper.jar`) vem incluído, por isso
serviços de build automáticos que exijam `./gradlew` funcionam sem alterações.
O jar é o oficial do repositório `gradle/gradle`, tag `v8.9.0`
(SHA-256 `498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17`).

Se o `gradlew` não tiver permissão de execução: `chmod +x gradlew`.

---

## Instalar no telemóvel

Copia o `app-debug.apk` para o telefone e abre-o. O Android vai pedir para autorizares
**"Instalar apps desconhecidas"** para a app que estás a usar (Ficheiros, Chrome, etc.) —
é normal em instalações fora da Play Store.

O APK vem assinado com a chave de *debug*, o que serve perfeitamente para uso pessoal.
O build `release` está configurado para usar a mesma chave, de modo a que qualquer
serviço de compilação devolva um APK instalável. Para publicar na Play Store terias
de gerar uma chave própria e trocar o `signingConfig` no `app/build.gradle`.

---

## O que foi adaptado (e porquê)

O HTML não foi alterado. As adaptações estão todas no `MainActivity.java`:

| Detalhe | Porquê |
|---|---|
| Página servida em `https://appassets.androidplatform.net/` em vez de `file://` | Dá um *secure context* ao WebView. Sem isso o `crypto.randomUUID()` não existe e a app rebentava ao adicionar imóveis e movimentos. |
| `setDomStorageEnabled(true)` | Sem isto o `localStorage` não grava — perdias tudo ao fechar. |
| `WebChromeClient` definido | Sem ele o WebView ignora `prompt()`, `confirm()` e `alert()`, que é como a app pede o nome do imóvel, o montante, a data. |
| Ponte `window.Android.shareText()` | O teu código já a procurava (`if(window.Android?.shareText)`). O botão **Partilhar** abre agora o menu de partilha do Android. |
| Interceção de downloads `blob:` | O WebView não sabe descarregar blobs. **Exportar CSV** e **Exportar dados** gravam agora em *Transferências*, com o nome de ficheiro correto. |
| `forceDarkAllowed=false` | A app só tem cores claras; evita que o Android lhe aplique um modo escuro automático com resultados estranhos. |
| Barra de estado a `#F7F8FA` | Igual ao `theme-color` do HTML. |

**Sem permissões declaradas.** A gravação em Transferências usa o MediaStore (Android 10+),
que dispensa permissões de armazenamento.

## Especificações

- `applicationId`: `pt.gestorimobiliario.app`
- Mínimo: Android 10 (API 29) · Alvo: Android 15 (API 35)
- AGP 8.7.3 · Gradle 8.9 · JDK 17
- Única dependência: `androidx.webkit`

## Atualizar a app mais tarde

Substitui `app/src/main/assets/index.html` pela versão nova do HTML e compila outra vez.
Convém subir o `versionCode` e o `versionName` no `app/build.gradle` para o Android
reconhecer a atualização.
