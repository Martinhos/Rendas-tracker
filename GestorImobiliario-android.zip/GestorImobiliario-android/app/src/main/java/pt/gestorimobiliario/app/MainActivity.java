package pt.gestorimobiliario.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewFeature;

import java.io.OutputStream;

/**
 * Embrulho nativo para a app HTML "Gestor Imobiliario".
 *
 * A pagina e servida a partir de https://appassets.androidplatform.net/assets/index.html
 * (e nao de file://) porque isso da um "secure context" ao WebView. Sem isso,
 * crypto.randomUUID() nao existe e a app rebenta ao adicionar imoveis/movimentos.
 */
public class MainActivity extends Activity {

    private static final String DOMAIN = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + DOMAIN + "/assets/index.html";

    private WebView web;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(DOMAIN)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // sem isto o localStorage nao grava nada
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);                // ignora tamanhos de fonte gigantes do sistema

        // A app so tem cores claras: desliga o dark mode automatico do WebView.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, false);
        }

        // Obrigatorio: sem WebChromeClient, o WebView ignora prompt()/confirm()/alert(),
        // que e como a app pede o nome do imovel, o montante, etc.
        web.setWebChromeClient(new WebChromeClient());

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (DOMAIN.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(DOWNLOAD_SHIM, null);
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");

        // Rede de seguranca: se algum download escapar ao shim de JS.
        web.setDownloadListener((url, agent, disposition, mime, size) -> {
            if (url.startsWith("blob:")) {
                web.evaluateJavascript(
                        "fetch('" + url + "').then(r=>r.blob()).then(b=>{var f=new FileReader();" +
                        "f.onloadend=function(){Android.saveFile('exportacao','',String(f.result))};" +
                        "f.readAsDataURL(b)})", null);
            }
        });

        boolean restored = state != null && web.restoreState(state) != null;
        if (!restored) web.loadUrl(START_URL);
    }

    /**
     * A app exporta CSV/JSON com <a download href="blob:...">.click().
     * O WebView nao sabe descarregar blobs, por isso intercetamos o click,
     * lemos o blob em base64 e gravamos o ficheiro em Transferencias.
     */
    private static final String DOWNLOAD_SHIM =
            "(function(){if(window.__giShim)return;window.__giShim=1;" +
            "var c=HTMLAnchorElement.prototype.click;" +
            "HTMLAnchorElement.prototype.click=function(){try{" +
            "var h=this.getAttribute('href')||'',n=this.getAttribute('download');" +
            "if(n&&(h.indexOf('blob:')===0||h.indexOf('data:')===0)){" +
            "fetch(h).then(function(r){return r.blob()}).then(function(b){" +
            "var f=new FileReader();f.onloadend=function(){Android.saveFile(n,b.type||'',String(f.result))};" +
            "f.readAsDataURL(b)})['catch'](function(e){Android.toast('Nao foi possivel exportar: '+e)});return;}" +
            "}catch(e){}return c.apply(this,arguments)}})()";

    private final class Bridge {

        /** Chamado por shareReport() na app: window.Android.shareText(titulo, texto). */
        @JavascriptInterface
        public void shareText(final String title, final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, title == null ? "" : title);
                i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                try {
                    startActivity(Intent.createChooser(i, "Partilhar relatorio"));
                } catch (ActivityNotFoundException e) {
                    toast("Nenhuma app disponivel para partilhar.");
                }
            });
        }

        /** Grava um data-URL em Transferencias (MediaStore, sem permissoes). */
        @JavascriptInterface
        public void saveFile(String name, String mime, String dataUrl) {
            try {
                int comma = dataUrl.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("data-URL invalido");
                byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);

                // b.type vem como "text/csv;charset=utf-8"; o MediaStore so quer "text/csv".
                if (mime != null) mime = mime.split(";")[0].trim();
                if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
                if (name == null || name.isEmpty()) name = "exportacao";

                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                cv.put(MediaStore.Downloads.IS_PENDING, 1);

                Uri uri = getContentResolver()
                        .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new IllegalStateException("sem acesso a Transferencias");

                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("sem acesso ao ficheiro");
                    out.write(bytes);
                }

                cv.clear();
                cv.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, cv, null, null);

                toast("Guardado em Transferencias: " + name);
            } catch (Exception e) {
                toast("Nao foi possivel guardar: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void toast(String msg) {
            MainActivity.this.toast(msg);
        }
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
