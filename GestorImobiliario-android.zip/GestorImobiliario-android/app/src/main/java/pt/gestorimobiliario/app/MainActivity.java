package pt.gestorimobiliario.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Embrulho nativo da app HTML "Gestor Imobiliario".
 *
 * A pagina e servida de https://appassets.androidplatform.net/assets/index.html
 * e nao de file://, porque so assim o WebView lhe da um "secure context" —
 * sem isso nao existe crypto.randomUUID() e a app rebenta ao criar registos.
 */
public class MainActivity extends Activity {

    private static final String DOMAIN = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + DOMAIN + "/assets/index.html";

    private static final int REQ_PICK_FORM = 11;   // <input type="file"> da pagina
    private static final int REQ_CREATE_DOC = 12;  // guardar copia (Drive, Ficheiros, ...)
    private static final int REQ_OPEN_DOC = 13;    // abrir copia
    private static final int REQ_LINK_AUTO = 14;   // escolher o destino da copia automatica

    private static final String PREFS = "gi";
    private static final String K_AUTO_URI = "auto_uri";
    private static final String K_AUTO_NAME = "auto_name";
    private static final String K_AUTO_WHEN = "auto_when";

    private WebView web;
    private ValueCallback<Uri[]> formCallback;
    private byte[] pendingBytes;
    private SharedPreferences prefs;
    private String insetsJs;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(DOMAIN)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        web = new WebView(this);
        setContentView(web);

        // A partir do Android 15 as apps sao desenhadas de bordo a bordo, por isso
        // a pagina passava por baixo da barra de estado. Empurramos o WebView para
        // dentro da area segura em vez de deixar o cabecalho tapado.
        // Desenhamos de bordo a bordo em todas as versoes e entregamos as medidas
        // da area segura a propria pagina, em vez de a empurrar com padding: assim
        // o fundo do cabecalho estende-se por baixo da barra de estado, mas o
        // conteudo nunca fica tapado.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        ViewCompat.setOnApplyWindowInsetsListener(web, (v, windowInsets) -> {
            Insets bars = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            float d = getResources().getDisplayMetrics().density;
            insetsJs = String.format(Locale.US,
                    "window.__setInsets && window.__setInsets(%.1f,%.1f,%.1f,%.1f)",
                    bars.top / d, bars.bottom / d, bars.left / d, bars.right / d);
            runJs(insetsJs);
            return windowInsets;
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);       // localStorage
        s.setDatabaseEnabled(true);         // IndexedDB (anexos dos contratos)
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);

        // A pagina tem tema escuro proprio: deixamos o WebView entregar-lhe a
        // preferencia do sistema (prefers-color-scheme) em vez de escurecer a forca.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, true);
        }

        // Sem WebChromeClient o WebView ignora os dialogos de JS e os <input type="file">.
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (formCallback != null) formCallback.onReceiveValue(null);
                formCallback = cb;
                // Nao usamos params.createIntent(): ele restringe o seletor aos tipos do
                // atributo accept, e um CSV exportado do Splitwise chega ao dispositivo como
                // application/octet-stream ou vnd.ms-excel — ficava a cinzento, impossivel
                // de escolher. Abrimos tudo, excepto quando so se pedem imagens.
                // Antes bastava um accept vazio para o seletor abrir so com imagens.
                // Agora so restringimos se houver tipos declarados e forem todos imagens.
                boolean onlyImages = false;
                int declared = 0;
                String[] accept = params.getAcceptTypes();
                if (accept != null) {
                    boolean all = true;
                    for (String a : accept) {
                        if (a == null || a.trim().isEmpty()) continue;
                        declared++;
                        if (!a.trim().toLowerCase(Locale.US).startsWith("image/")) { all = false; }
                    }
                    onlyImages = declared > 0 && all;
                }
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(onlyImages ? "image/*" : "*/*");
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(i, REQ_PICK_FORM);
                    return true;
                } catch (Exception e) {
                    formCallback = null;
                    toast("Nao foi possivel abrir o seletor de ficheiros.");
                    return false;
                }
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (DOMAIN.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(DOWNLOAD_SHIM, null);
                if (insetsJs != null) v.evaluateJavascript(insetsJs, null);  // a pagina recarregou
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");

        // Rede de seguranca para downloads que escapem ao shim.
        web.setDownloadListener((url, agent, disposition, mime, size) -> {
            if (url.startsWith("blob:")) {
                web.evaluateJavascript(
                        "fetch('" + url + "').then(r=>r.blob()).then(b=>{var f=new FileReader();" +
                        "f.onloadend=function(){Android.saveAs('exportacao',b.type||'',String(f.result).split(',')[1])};" +
                        "f.readAsDataURL(b)})", null);
            }
        });

        boolean restored = state != null && web.restoreState(state) != null;
        if (!restored) web.loadUrl(START_URL);
    }

    /**
     * A app descarrega CSV, copias de seguranca e anexos com <a download href="blob:">.
     * O WebView nao sabe tratar blobs: intercetamos o clique, lemos o conteudo em
     * base64 e entregamo-lo ao seletor do Android (onde aparece o Google Drive).
     */
    private static final String DOWNLOAD_SHIM =
            "(function(){if(window.__giShim)return;window.__giShim=1;" +
            "var c=HTMLAnchorElement.prototype.click;" +
            "HTMLAnchorElement.prototype.click=function(){try{" +
            "var h=this.getAttribute('href')||'',n=this.getAttribute('download');" +
            "if(n&&(h.indexOf('blob:')===0||h.indexOf('data:')===0)){" +
            "fetch(h).then(function(r){return r.blob()}).then(function(b){" +
            "var f=new FileReader();f.onloadend=function(){" +
            "Android.saveAs(n,b.type||'',String(f.result).split(',')[1])};" +
            "f.readAsDataURL(b)})['catch'](function(e){Android.toast('Nao foi possivel exportar: '+e)});return;}" +
            "}catch(e){}return c.apply(this,arguments)}})()";

    private final class Bridge {

        /** shareReport() na pagina: window.Android.shareText(titulo, texto). */
        @JavascriptInterface
        public void shareText(final String title, final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, title == null ? "" : title);
                i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                try {
                    startActivity(Intent.createChooser(i, "Partilhar"));
                } catch (ActivityNotFoundException e) {
                    toast("Nenhuma app disponivel para partilhar.");
                }
            });
        }

        /**
         * Abre o seletor "guardar em" do Android. O Google Drive aparece la como
         * destino, por isso nao precisamos de acesso a rede nem a conta do utilizador.
         */
        @JavascriptInterface
        public void saveAs(final String name, final String mime, final String base64) {
            try {
                pendingBytes = Base64.decode(base64, Base64.DEFAULT);
            } catch (Exception e) {
                toast("Conteudo invalido.");
                return;
            }
            final String type = (mime == null || mime.isEmpty()) ? "application/octet-stream"
                    : mime.split(";")[0].trim();
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(type);
                i.putExtra(Intent.EXTRA_TITLE, name == null || name.isEmpty() ? "ficheiro" : name);
                try {
                    startActivityForResult(i, REQ_CREATE_DOC);
                } catch (ActivityNotFoundException e) {
                    toast("Nao ha nenhuma app para guardar ficheiros.");
                }
            });
        }

        /** Abre um ficheiro (copia de seguranca ou CSV) e devolve-o a pagina. */
        @JavascriptInterface
        public void openFile(final String mime) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        mime == null || mime.isEmpty() ? "application/json" : mime,
                        "application/json", "text/csv", "text/plain", "text/comma-separated-values"});
                try {
                    startActivityForResult(i, REQ_OPEN_DOC);
                } catch (ActivityNotFoundException e) {
                    toast("Nao ha nenhuma app para escolher ficheiros.");
                }
            });
        }

        /** Estado da copia automatica, lido pela pagina no arranque. */
        @JavascriptInterface
        public String autoStatus() {
            String uri = prefs.getString(K_AUTO_URI, null);
            boolean linked = uri != null && hasPermission(uri);
            try {
                JSONObject o = new JSONObject();
                o.put("linked", linked);
                o.put("name", prefs.getString(K_AUTO_NAME, ""));
                o.put("when", prefs.getString(K_AUTO_WHEN, ""));
                return o.toString();
            } catch (Exception e) {
                return "{\"linked\":false}";
            }
        }

        /** Escolhe uma vez o destino (Google Drive, Ficheiros, ...) e guarda a autorizacao. */
        @JavascriptInterface
        public void linkAuto(final String name, final String base64) {
            try {
                pendingBytes = Base64.decode(base64, Base64.DEFAULT);
            } catch (Exception e) {
                pendingBytes = null;
            }
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, name == null || name.isEmpty() ? "gestor-imobiliario.json" : name);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try {
                    startActivityForResult(i, REQ_LINK_AUTO);
                } catch (ActivityNotFoundException e) {
                    toast("Nao ha nenhuma app para guardar ficheiros.");
                }
            });
        }

        /** Escrita silenciosa no destino ligado. Chamada a cada alteracao. */
        @JavascriptInterface
        public void autoSave(final String base64) {
            final String uri = prefs.getString(K_AUTO_URI, null);
            if (uri == null) { notifyAuto(false, "sem destino"); return; }
            byte[] bytes;
            try {
                bytes = Base64.decode(base64, Base64.DEFAULT);
            } catch (Exception e) {
                notifyAuto(false, "conteudo invalido");
                return;
            }
            if (writeTo(Uri.parse(uri), bytes)) {
                String when = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                prefs.edit().putString(K_AUTO_WHEN, when).apply();
                notifyAuto(true, when);
            } else {
                notifyAuto(false, "sem acesso ao ficheiro");
            }
        }

        @JavascriptInterface
        public void unlinkAuto() {
            String uri = prefs.getString(K_AUTO_URI, null);
            if (uri != null) {
                try {
                    getContentResolver().releasePersistableUriPermission(Uri.parse(uri),
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception ignored) { }
            }
            prefs.edit().remove(K_AUTO_URI).remove(K_AUTO_NAME).remove(K_AUTO_WHEN).apply();
        }

        @JavascriptInterface
        public void toast(String msg) { MainActivity.this.toast(msg); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);

        if (req == REQ_PICK_FORM) {
            if (formCallback == null) return;
            Uri[] picked = null;
            if (res == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    picked = new Uri[n];
                    for (int k = 0; k < n; k++) picked[k] = data.getClipData().getItemAt(k).getUri();
                } else if (data.getData() != null) {
                    picked = new Uri[]{data.getData()};
                }
            }
            if (res == RESULT_OK && picked == null) toast("Nenhum ficheiro escolhido.");
            formCallback.onReceiveValue(picked);
            formCallback = null;
            return;
        }

        if (req == REQ_CREATE_DOC) {
            byte[] bytes = pendingBytes;
            pendingBytes = null;
            if (res != RESULT_OK || data == null || data.getData() == null || bytes == null) return;
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out == null) throw new IllegalStateException("sem acesso ao ficheiro");
                out.write(bytes);
                toast("Guardado.");
            } catch (Exception e) {
                toast("Nao foi possivel guardar: " + e.getMessage());
            }
            return;
        }

        if (req == REQ_LINK_AUTO) {
            byte[] bytes = pendingBytes;
            pendingBytes = null;
            if (res != RESULT_OK || data == null || data.getData() == null) {
                runJs("window.__autoLinked && window.__autoLinked('{\"linked\":false}')");
                return;
            }
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {
                // alguns fornecedores nao dao permissao persistente; avisamos ja
                toast("Este destino nao permite gravar sozinho. Escolhe outra pasta.");
                runJs("window.__autoLinked && window.__autoLinked('{\"linked\":false}')");
                return;
            }
            String name = displayName(uri);
            boolean wrote = bytes == null || writeTo(uri, bytes);
            String when = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
            prefs.edit().putString(K_AUTO_URI, uri.toString())
                    .putString(K_AUTO_NAME, name)
                    .putString(K_AUTO_WHEN, wrote ? when : "").apply();
            try {
                JSONObject o = new JSONObject();
                o.put("linked", true);
                o.put("name", name);
                o.put("when", wrote ? when : "");
                runJs("window.__autoLinked && window.__autoLinked(" + JSONObject.quote(o.toString()) + ")");
            } catch (Exception ignored) { }
            return;
        }

        if (req == REQ_OPEN_DOC) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            Uri uri = data.getData();
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IllegalStateException("sem acesso ao ficheiro");
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int r;
                while ((r = in.read(chunk)) != -1) buf.write(chunk, 0, r);
                String text = buf.toString("UTF-8");
                String name = uri.getLastPathSegment();
                if (name == null) name = "ficheiro";
                final String js = "window.__fileLoaded && window.__fileLoaded("
                        + JSONObject.quote(name) + "," + JSONObject.quote(text) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            } catch (Exception e) {
                toast("Nao foi possivel ler o ficheiro: " + e.getMessage());
            }
        }
    }

    /** "wt" trunca: sem isso ficariam bytes da versao anterior no fim do ficheiro. */
    private boolean writeTo(Uri uri, byte[] bytes) {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) return false;
            out.write(bytes);
            out.flush();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean hasPermission(String uri) {
        try {
            for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
                if (p.getUri().toString().equals(uri) && p.isWritePermission()) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private String displayName(Uri uri) {
        String last = uri.getLastPathSegment();
        if (last == null) return "cópia";
        int slash = last.lastIndexOf('/');
        return slash >= 0 ? last.substring(slash + 1) : last;
    }

    private void notifyAuto(boolean okFlag, String info) {
        runJs("window.__autoResult && window.__autoResult(" + okFlag + "," + JSONObject.quote(info) + ")");
    }

    private void runJs(final String js) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
